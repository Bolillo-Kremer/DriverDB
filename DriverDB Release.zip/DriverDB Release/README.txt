-- GETTING STARTED --

Open the bin folder
Select DriverDB.UI.exe
Right-click and create shortcut
Cut and paste the shortcut wherever you want

Create a new DriverDB folder wherever you want

Run the shortcut
At the top menu click "Database Setting > Change Database Directory"
Click the "..." button and select your DriverDB folder
Click the "Save" button



-- QUICK TUTORIAL --

To add drivers go to File > New and fill out the information and click the "Save" button
To edit a driver go to File > Open and select an existing driver folder and click the "Save" button
To search for an old driver file, go to File > Search Old Driver Files and fill out the search parameters



-- HOW IT"S SETUP --

Every driver folder contains 3 files...
License-MM-dd-yyyy
MVR-MM-dd-yyyy
MedicalCard-MM-dd-yyyy

And another folder "Old" containing all the old driver files (Same naming convention)




